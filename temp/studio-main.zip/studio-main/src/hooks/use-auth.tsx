'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  getAuth,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  User,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import { auth as firebaseAuth } from '@/lib/firebase/config';
import { usePathname, useRouter } from 'next/navigation';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: typeof signInWithEmailAndPassword;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(firebaseAuth, (user) => {
      setUser(user);
      setLoading(false);
      
      // Handle redirection after auth state changes
      if (user) {
        // If user is logged in and on the login page, redirect to home
        if (pathname === '/login') {
          router.push('/');
        }
      } else {
        // If user is not logged in and not on the login page, redirect to login
        if (pathname !== '/login') {
          router.push('/login');
        }
      }
    });

    return () => unsubscribe();
  }, [user, pathname, router]);

  const loginWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(firebaseAuth, provider);
      // Redirection is handled by the useEffect hook
    } catch (error) {
      console.error('Error during Google sign-in:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(firebaseAuth);
      // Redirection is handled by the useEffect hook
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const value = {
    user,
    loading,
    login: async (email, password) => {
        try {
            // We pass the auth instance here explicitly
            return await signInWithEmailAndPassword(firebaseAuth, email, password);
        } catch (error) {
            console.error("Error signing in with email and password:", error);
            throw error;
        }
    },
    loginWithGoogle,
    logout,
  };

  // Render children only when not loading to avoid flickering
  if (loading) {
    return null; // Or a loading spinner
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
