'use client';

import { useState, useRef, useEffect } from 'react';
import type { Message } from '@/lib/types';
import { getBotResponse } from '@/app/actions';
import { BotMessage } from '@/components/bot-message';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BotIcon, UserIcon } from './icons';
import { Send, LoaderCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const initialMessages: Message[] = [
    {
      id: 'init1',
      role: 'bot',
      content: <BotMessage response={{ type: 'none', answer: "Hello! I am an administrative assistant bot. You can ask me about student records, attendance, and marks.\n\nFor example: 'What was Alice Johnson's attendance on 2024-05-20?'" }} />
    }
  ]

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: <p>{input}</p>,
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setInput('');

    try {
      const response = await getBotResponse(input);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'bot',
        content: <BotMessage response={response} />,
      };
      if (response.type === 'error') {
        toast({
          variant: "destructive",
          title: "Error",
          description: response.answer,
        })
      }
      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "An unexpected error occurred.",
        description: "Please check the console or try again later."
      })
      const errorMessage: Message = {
        id: 'error-' + Date.now().toString(),
        role: 'bot',
        content: <BotMessage response={{type: 'error', answer: 'Sorry, something went wrong on my end.'}} />
      }
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="shadow-2xl shadow-primary/10">
      <CardHeader className="text-center">
        {/* The main title is on the page, header can be minimal */}
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[50vh] w-full pr-4" ref={scrollAreaRef}>
          <div className="space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start gap-4 ${
                  message.role === 'user' ? 'justify-end' : ''
                }`}
              >
                {message.role === 'bot' && (
                  <Avatar className="h-9 w-9 border bg-primary text-primary-foreground">
                    <AvatarFallback>
                      <BotIcon className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`max-w-[75%] rounded-lg p-3 text-sm ${
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-card border'
                  }`}
                >
                  {message.content}
                </div>
                {message.role === 'user' && (
                    <Avatar className="h-9 w-9 border bg-accent text-accent-foreground">
                        <AvatarFallback>
                            <UserIcon className="h-5 w-5" />
                        </AvatarFallback>
                    </Avatar>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex items-start gap-4">
                 <Avatar className="h-9 w-9 border bg-primary text-primary-foreground">
                    <AvatarFallback>
                      <BotIcon className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="max-w-[75%] rounded-lg p-3 text-sm bg-card border">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <LoaderCircle className="h-4 w-4 animate-spin" />
                      <span>Typing...</span>
                    </div>
                  </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter>
        <form onSubmit={handleSubmit} className="flex w-full items-center gap-2">
          <Input
            type="text"
            placeholder="Ask an administrative question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            className="flex-1"
          />
          <Button type="submit" size="icon" disabled={isLoading || !input.trim()} className="bg-accent hover:bg-accent/90">
            <Send className="h-4 w-4" />
            <span className="sr-only">Send</span>
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
