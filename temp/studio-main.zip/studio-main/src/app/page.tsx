'use client';
import ChatInterface from '@/components/chat-interface';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { LogOut } from 'lucide-react';

export default function Home() {
  const { user, logout } = useAuth();

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-3xl mx-auto">
        <header className="flex justify-between items-center text-center mb-8">
          <div></div>
          <div>
            <h1 className="font-headline text-4xl md:text-5xl font-bold text-primary">
              Real-time Data Retrieval Bot
            </h1>
            <p className="text-muted-foreground mt-2 text-lg">
              Your AI-powered administrative assistant
            </p>
          </div>
          {user && (
            <Button variant="ghost" onClick={logout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          )}
        </header>
        <ChatInterface />
      </div>
    </main>
  );
}
