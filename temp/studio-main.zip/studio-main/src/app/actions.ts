'use server';

import type { BotResponse } from '@/lib/types';
import { partialEvidenceReasoning } from '@/ai/flows/partial-evidence-reasoning';

export async function getBotResponse(query: string): Promise<BotResponse> {
  try {
    const aiResponse = await partialEvidenceReasoning({ query });

    // If the AI couldn't find an answer, it will return the specific string "NOT_FOUND".
    if (aiResponse.answer === 'NOT_FOUND') {
      return {
        type: 'none',
        answer: "I couldn't find a record matching your request. Please check the details and try again.",
        confidence: aiResponse.confidenceLevel || 0.9, // High confidence that the record doesn't exist.
      };
    }

    return {
      type: 'partial', // The AI's reasoning is partial based on available data.
      answer: aiResponse.answer,
      confidence: aiResponse.confidenceLevel,
    };
  } catch (error: any) {
    console.error('Error in getBotResponse:', error);

    // This is a fallback for unexpected system errors, not for "not found" cases.
    return {
      type: 'error',
      answer:
        'I encountered an unexpected problem. Please try rephrasing your question or try again later.',
    };
  }
}
