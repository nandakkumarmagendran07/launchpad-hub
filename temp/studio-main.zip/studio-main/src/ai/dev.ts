import { config } from 'dotenv';
config();

import '@/ai/flows/partial-evidence-reasoning.ts';