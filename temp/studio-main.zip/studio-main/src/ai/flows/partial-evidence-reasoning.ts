'use server';

/**
 * @fileOverview Implements partial evidence reasoning for the chatbot when a perfect record match is not available.
 *
 * - partialEvidenceReasoning - A function that performs reasoning based on partial evidence.
 * - PartialEvidenceReasoningInput - The input type for the partialEvidenceReasoning function.
 * - PartialEvidenceReasoningOutput - The return type for the partialEvidenceReasoning function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import * as db from '@/lib/db';
import { getAttendanceByName } from '@/lib/db';

const PartialEvidenceReasoningInputSchema = z.object({
  query: z.string().describe('The user query to be answered.'),
});
export type PartialEvidenceReasoningInput = z.infer<
  typeof PartialEvidenceReasoningInputSchema
>;

const PartialEvidenceReasoningOutputSchema = z.object({
  answer: z
    .string()
    .describe(
      'The final, user-facing answer in plain English. If no record is found, this MUST be the exact string "NOT_FOUND".'
    ),
  confidenceLevel: z
    .number()
    .describe('The confidence level in the generated answer (0-1).'),
});

export type PartialEvidenceReasoningOutput = z.infer<
  typeof PartialEvidenceReasoningOutputSchema
>;

export async function partialEvidenceReasoning(
  input: PartialEvidenceReasoningInput
): Promise<PartialEvidenceReasoningOutput> {
  return partialEvidenceReasoningFlow(input);
}


const getAttendanceByNameTool = ai.defineTool(
  {
    name: "getAttendanceByName",
    description: "Fetch attendance status for a student on a specific date. Use this for all attendance-related questions.",
    inputSchema: z.object({
      studentName: z.string().describe("The student's full name, e.g., 'Alice Johnson'"),
      date: z.string().describe("The date in YYYY-MM-DD format, e.g., '2024-05-20'")
    }),
    outputSchema: z.object({
      status: z.string().nullable()
    })
  },
  async ({ studentName, date }) => {
    return await getAttendanceByName(studentName, date);
  }
);


const findFacultyByName = ai.defineTool(
  {
    name: 'findFacultyByName',
    description: 'Find a faculty member by their name.',
    inputSchema: z.object({name: z.string()}),
    outputSchema: z.any(),
  },
  async ({name}) => db.findFacultyByName(name)
);

const getMarks = ai.defineTool(
  {
    name: 'getMarks',
    description: 'Get marks for a student in a specific subject. You must have the student\'s ID to use this tool.',
    inputSchema: z.object({studentId: z.string(), subject: z.string()}),
    outputSchema: z.any(),
  },
  async ({studentId, subject}) => db.getMarks(studentId, subject)
);

const getLabLogsForStudent = ai.defineTool(
  {
    name: 'getLabLogsForStudent',
    description: 'Get lab logs for a specific student. You must have the student\'s ID to use this tool.',
    inputSchema: z.object({studentId: z.string()}),
    outputSchema: z.any(),
  },
  async ({studentId}) => db.getLabLogsForStudent(studentId)
);

const getStudentCount = ai.defineTool(
  {
    name: 'getStudentCount',
    description: 'Get the total number of students.',
    inputSchema: z.object({}),
    outputSchema: z.number(),
  },
  async () => db.getStudentCount()
);

const getAllStudents = ai.defineTool(
    {
        name: 'getAllStudents',
        description: 'Get a list of all students in the database. Use this for queries like "list all students" or "who are the students".',
        inputSchema: z.object({}),
        outputSchema: z.any(),
    },
    async () => db.getAllStudents()
);

const getStudentRecords = ai.defineTool(
  {
    name: 'getStudentRecords',
    description: "Get all records for a specific student, including all their attendance, marks, and lab logs. To use this, you must first find the student's ID using another tool if you don't already have it.",
    inputSchema: z.object({studentId: z.string()}),
    outputSchema: z.any(),
  },
  async ({studentId}) => db.getStudentRecords(studentId)
);

const getAllData = ai.defineTool(
    {
      name: 'getAllData',
      description: 'Get all data from the database, including students, attendance, marks, lab logs, and faculty.',
      inputSchema: z.object({}),
      outputSchema: z.any(),
    },
    async () => db.getAllData()
);

const getTimetable = ai.defineTool(
    {
        name: 'getTimetable',
        description: 'Get the timetable for a specific day.',
        inputSchema: z.object({day: z.string()}),
        outputSchema: z.any(),
    },
    async ({day}) => db.getTimetable(day)
);

const getClassAssignment = ai.defineTool(
    {
        name: 'getClassAssignment',
        description: 'Get the class assignment for a specific class ID.',
        inputSchema: z.object({classId: z.string()}),
        outputSchema: z.any(),
    },
    async ({classId}) => db.getClassAssignment(classId)
);


const prompt = ai.definePrompt({
  name: 'partialEvidenceReasoningPrompt',
  input: {schema: PartialEvidenceReasoningInputSchema},
  output: {schema: PartialEvidenceReasoningOutputSchema},
  tools: [
    getAttendanceByNameTool,
    findFacultyByName,
    getMarks,
    getLabLogsForStudent,
    getStudentCount,
    getAllStudents,
    getStudentRecords,
    getAllData,
    getTimetable,
    getClassAssignment,
  ],
  prompt: `You are an AI assistant that converts structured data from a database into a simple, user-friendly English sentence. You MUST NOT use your own knowledge or make assumptions.

**CORE RULES:**
1.  **Analyze the User's Query**: Understand what the user is asking for.
2.  **Select the Correct Tool**: Based on the query, choose the ONE most appropriate tool from the available list. For all attendance questions, you MUST call the getAttendanceByName tool.
3.  **Wait for Tool Output**: Execute the tool and wait for the structured JSON data to be returned.
4.  **Format the Answer**: Convert the JSON data into a simple, clear English sentence based on the rules below.
5.  **Handle Tool Failure**: If you are asked an attendance question and the getAttendanceByName tool is not executed or fails, your answer MUST be the exact string "Internal error: attendance tool was not invoked.".

**ANSWERING RULES BASED ON TOOL OUTPUT:**

*   **For Attendance Queries (using \`getAttendanceByName\`)**:
    *   You will receive a JSON object like \`{ "status": "Present" }\`, \`{ "status": "Absent" }\`, or \`{ "status": null }\`.
    *   If \`status\` is "Present", your answer MUST be: "Yes, [studentName] was present on [date]." (filling in the name and date from the user's query).
    *   If \`status\` is "Absent", your answer MUST be: "No, [studentName] was absent on [date]." (filling in the name and date from the user's query).
    *   If \`status\` is null, your answer MUST be: "Attendance records for [studentName] on [date] are not available." (filling in the name and date).

*   **For All Other Queries**:
    *   If the tool returns data, summarize it clearly and concisely.
    *   If the tool returns \`null\` or no data, your answer MUST be: "NOT_FOUND".

**User Query:** {{{query}}}

Format your final response as a JSON object with "answer" and "confidenceLevel" fields.
Set confidenceLevel to 1.0 if you successfully formatted data from a tool.
Set confidenceLevel to 0.9 if the tool returned no data and you are answering "NOT_FOUND".
Do not include confidence scores for attendance answers.
`,
});

const partialEvidenceReasoningFlow = ai.defineFlow(
  {
    name: 'partialEvidenceReasoningFlow',
    inputSchema: PartialEvidenceReasoningInputSchema,
    outputSchema: PartialEvidenceReasoningOutputSchema,
  },
  async (input) => {
    try {
      const {output, history} = await prompt(input);
      
      const hasAttendanceToolCall = history.some(event => 
        event.type === 'toolRequest' &&
        Array.isArray(event.request.tools) &&
        event.request.tools.some(tool => tool.toolName === 'getAttendanceByName')
      );

      const isAttendanceQuery = /attendance/i.test(input.query);

      if (isAttendanceQuery && !hasAttendanceToolCall) {
          return {
              answer: "Internal error: attendance tool was not invoked.",
              confidenceLevel: 0.1
          };
      }

      if (!output || !output.answer) {
        return {
          answer: 'NOT_FOUND',
          confidenceLevel: 0.2,
        };
      }
      return output;
    } catch (error) {
      console.error("Error in partialEvidenceReasoningFlow:", error);
      return {
        answer: 'NOT_FOUND',
        confidenceLevel: 0.9,
      };
    }
  }
);
