import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// This middleware function will be removed as the logic is now handled
// in the AuthProvider. This is to avoid conflicting redirection logic.
export function middleware(request: NextRequest) {
  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
