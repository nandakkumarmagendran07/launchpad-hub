// This script is used to seed the Firestore database with initial data.
// To run it, use: `npm run seed`
// Make sure you have configured your Firebase Admin SDK credentials correctly.
// E.g., by setting the GOOGLE_APPLICATION_CREDENTIALS environment variable.

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';

// IMPORTANT: Replace with your actual service account key details
// You can download this from your Firebase project settings.
// It's recommended to use environment variables for this in production.
const serviceAccount = {
  projectId: "studio-1153264247-72a2a",
  clientEmail: "firebase-adminsdk-3yqjq@studio-1153264247-72a2a.iam.gserviceaccount.com",
  // Use a secure way to load the private key, e.g. environment variables.
  // The key must be the full string from the JSON file, including "-----BEGIN PRIVATE KEY-----" etc.
  // Replace the placeholder below with your actual private key.
  privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n') || "ADD_YOUR_PRIVATE_KEY_HERE",
};


if (getApps().length === 0) {
  initializeApp({
    credential: cert(serviceAccount)
  });
}

const db = getFirestore();

const students = [
  { _id: 'S001', name: 'Alice Johnson', course: 'Computer Science' },
  { _id: 'S002', name: 'Bob Williams', course: 'Data Science' },
  { _id: 'S003', name: 'Charlie Brown', course: 'Information Technology' },
  { _id: 'S004', name: 'Diana Miller', course: 'Computer Science' },
  { _id: 'S005', name: 'Ethan Jones', course: 'Data Science' },
  { _id: 'S006', name: 'Fiona Davis', course: 'Cybersecurity' },
  { _id: 'S007', name: 'George Garcia', course: 'Computer Science' },
  { _id: 'S008', name: 'Hannah Rodriguez', course: 'Information Technology' },
  { _id: 'S009', name: 'Ivan Martinez', course: 'Data Science' },
  { _id: 'S010', name: 'Jane Hernandez', course: 'Cybersecurity' },
  { _id: 'S011', name: 'Kevin Lopez', course: 'Computer Science' },
  { _id: 'S012', name: 'Laura Gonzalez', course: 'Data Science' },
  { _id: 'S013', name: 'Mason Wilson', course: 'Information Technology' },
  { _id: 'S014', name: 'Nora Anderson', course: 'Cybersecurity' },
  { _id: 'S015', name: 'Oscar Thomas', course: 'Computer Science' },
  { _id: 'S016', name: 'Penelope Taylor', course: 'Data Science' },
  { _id: 'S017', name: 'Quinn Moore', course: 'Information Technology' },
  { _id: 'S018', name: 'Rachel Jackson', course: 'Cybersecurity' },
  { _id: 'S019', name: 'Steven White', course: 'Computer Science' },
  { _id: 'S020', name: 'Tina Harris', course: 'Data Science' },
  { _id: 'S021', name: 'Umar Martin', course: 'Information Technology' },
  { _id: 'S022', name: 'Violet Thompson', course: 'Cybersecurity' },
  { _id: 'S023', name: 'Walter Garcia', course: 'Computer Science' },
  { _id: 'S024', name: 'Xena Martinez', course: 'Data Science' },
  { _id: 'S025', name: 'Yusuf Robinson', course: 'Information Technology' },
  { _id: 'S026', name: 'Zane Clark', course: 'Cybersecurity' },
  { _id: 'S027', name: 'Amy Lewis', course: 'Computer Science' },
  { _id: 'S028', name: 'Ben Walker', course: 'Data Science' },
  { _id: 'S029', name: 'Clara Hall', course: 'Information Technology' },
  { _id: 'S030', name: 'Daniel Allen', course: 'Cybersecurity' },
];

const faculty = [
    {_id: 'F001', name: 'Dr. Evelyn Reed', department: 'Computer Science'},
    {_id: 'F002', name: 'Dr. Samuel Croft', department: 'Data Science'},
    {_id: 'F003', name: 'Prof. Angela Yu', department: 'Information Technology'},
    {_id: 'F004', name: 'Dr. Alan Turing', department: 'Computer Science'},
    {_id: 'F005', name: 'Prof. Ada Lovelace', department: 'Cybersecurity'},
    {_id: 'F006', name: 'Dr. Bernard Shaw', department: 'Data Science'},
    {_id: 'F007', name: 'Prof. Charles Kane', department: 'Information Technology'},
    {_id: 'F008', name: 'Dr. Diana Prince', department: 'Computer Science'},
    {_id: 'F009', name: 'Prof. Edward Nigma', department: 'Cybersecurity'},
    {_id: 'F010', name: 'Dr. Frank Castle', department: 'Data Science'},
];

const attendance = [
    // Alice Johnson
    { studentId: 'S001', date: '2024-05-20', status: 'Present' },
    { studentId: 'S001', date: '2024-05-21', status: 'Present' },
    // Bob Williams
    { studentId: 'S002', date: '2024-05-20', status: 'Absent' },
    // Charlie Brown
    { studentId: 'S003', date: '2024-05-21', status: 'Present' },
    // Diana Miller
    { studentId: 'S004', date: '2024-05-22', status: 'Absent' },
    // Ethan Jones
    { studentId: 'S005', date: '2024-05-22', status: 'Present' },
    // Fiona Davis
    { studentId: 'S006', date: '2024-05-23', status: 'Present' },
    // George Garcia
    { studentId: 'S007', date: '2024-05-23', status: 'Late' },
];

const marks = [
    { studentId: 'S001', subject: 'Algorithms', score: 88 },
    { studentId: 'S001', subject: 'Databases', score: 92 },
    { studentId: 'S002', subject: 'Statistics', score: 76 },
    { studentId: 'S003', subject: 'Networking', score: 81 },
];

const labLogs = [
    { studentId: 'S001', lab: 'CS101', login: '2024-05-20T09:00:00', logout: '2024-05-20T11:00:00' },
    { studentId: 'S004', lab: 'CS101', login: '2024-05-20T09:05:00', logout: '2024-05-20T10:55:00' },
];

const timetable = [
    {
        day: 'Monday',
        schedule: [
            { time: '09:00-10:00', classId: 'C01', subject: 'Algorithms' },
            { time: '10:00-11:00', classId: 'C02', subject: 'Statistics' },
        ]
    },
    {
        day: 'Tuesday',
        schedule: [
            { time: '09:00-10:00', classId: 'C03', subject: 'Networking' },
            { time: '11:00-12:00', classId: 'C04', subject: 'Cybersecurity Basics' },
        ]
    }
];

const classAssignments = [
    { classId: 'C01', facultyId: 'F001', studentIds: ['S001', 'S004', 'S007', 'S011', 'S015', 'S019', 'S023', 'S027'] },
    { classId: 'C02', facultyId: 'F002', studentIds: ['S002', 'S005', 'S009', 'S012', 'S016', 'S020', 'S024', 'S028'] },
    { classId: 'C03', facultyId: 'F003', studentIds: ['S003', 'S008', 'S013', 'S017', 'S021', 'S025', 'S029'] },
    { classId: 'C04', facultyId: 'F005', studentIds: ['S006', 'S010', 'S014', 'S018', 'S022', 'S026', 'S030'] },
];

async function seedDatabase() {
    console.log("Starting to seed database...");
    const batch = db.batch();

    // Seed students
    console.log("Seeding students...");
    for (const student of students) {
        const { _id, ...studentData } = student;
        const studentRef = db.collection('students').doc(_id);
        // Add studentId field inside the document for querying purposes
        batch.set(studentRef, { ...studentData, studentId: _id });
    }
    console.log("...students queued.");

    // Seed attendance
    console.log("Seeding attendance...");
    for (const att of attendance) {
        // Use a composite key for the document ID to ensure uniqueness
        const attRef = db.collection('attendance').doc(`${att.studentId}_${att.date}`);
        batch.set(attRef, att);
    }
    console.log("...attendance queued.");

    // Seed marks
    console.log("Seeding marks...");
    for (const mark of marks) {
        const markRef = db.collection('marks').doc(); // Auto-generate ID
        batch.set(markRef, mark);
    }
    console.log("...marks queued.");

    // Seed lab logs
    console.log("Seeding lab logs...");
    for (const log of labLogs) {
        const logRef = db.collection('labLogs').doc(); // Auto-generate ID
        batch.set(logRef, log);
    }
    console.log("...lab logs queued.");


    // Seed faculty
    console.log("Seeding faculty...");
    for (const fac of faculty) {
        const { _id, ...facData } = fac;
        const facRef = db.collection('faculty').doc(_id);
        batch.set(facRef, facData);
    }
    console.log("...faculty queued.");
    
    // Seed timetable
    console.log("Seeding timetable...");
    for (const daySchedule of timetable) {
        const { day, ...scheduleData } = daySchedule;
        const dayRef = db.collection('timetable').doc(day);
        batch.set(dayRef, scheduleData);
    }
    console.log("...timetable queued.");

    // Seed class assignments
    console.log("Seeding class assignments...");
    for (const assignment of classAssignments) {
        const { classId, ...assignmentData } = assignment;
        const assignmentRef = db.collection('classAssignments').doc(classId);
        batch.set(assignmentRef, assignmentData);
    }
    console.log("...class assignments queued.");

    // Commit the batch
    try {
        await batch.commit();
        console.log("Database seeded successfully!");
    } catch (error) {
        console.error("Error seeding database: ", error);
    }
}

// Check if private key is a placeholder before running
if (serviceAccount.privateKey === 'ADD_YOUR_PRIVATE_KEY_HERE') {
    console.error("\n\nERROR: Please add your Firebase private key to `src/lib/seed.ts`.\n");
    console.error("You can find your key in your Firebase project settings under Service Accounts.\n");
    console.error("It is highly recommended to store this key in an environment variable (FIREBASE_PRIVATE_KEY) for security.\n");
} else {
    seedDatabase();
}
