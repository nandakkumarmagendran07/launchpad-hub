export type QueryType = 'ATTENDANCE' | 'MARKS' | 'LOGS' | 'COUNT_STUDENTS' | 'UNKNOWN';

export type ParsedQuery = {
  name?: string;
  date?: string;
  subject?: string;
  queryType: QueryType;
  originalQuery: string;
};

export function parseQuery(query: string): ParsedQuery {
  // Regex to find a capitalized two-word name
  const nameRegex = /([A-Z][a-z]+ [A-Z][a-z]+)/;
  // Regex to find a date in YYYY-MM-DD format
  const dateRegex = /(\d{4}-\d{2}-\d{2})/;
  // Regex to find a subject, often following keywords like "in", "for", "of"
  const subjectRegex = /(?:in|for|of)\s+([A-Za-z\s]+)/i;

  let queryType: QueryType = 'UNKNOWN';
  if (/\b(how many|count|total number of) students\b/i.test(query)) {
    queryType = 'COUNT_STUDENTS';
  } else if (/\b(attendance)\b/i.test(query)) {
    queryType = 'ATTENDANCE';
  } else if (/\b(marks|score|grade)\b/i.test(query)) {
    queryType = 'MARKS';
  } else if (/\b(log|logs)\b/i.test(query)) {
    queryType = 'LOGS';
  }

  const nameMatch = query.match(nameRegex);
  const dateMatch = query.match(dateRegex);
  const subjectMatch = query.match(subjectRegex);

  // For subjects, we might not have a keyword, so we can try a fallback for 'marks' queries
  let subject = subjectMatch?.[1]?.trim();
  if (!subject && queryType === 'MARKS') {
      const simpleSubjectRegex = /marks in (\w+)/i;
      const simpleMatch = query.match(simpleSubjectRegex);
      if(simpleMatch) subject = simpleMatch[1];
  }


  return {
    name: nameMatch?.[1].trim(),
    date: dateMatch?.[1].trim(),
    subject,
    queryType,
    originalQuery: query,
  };
}
