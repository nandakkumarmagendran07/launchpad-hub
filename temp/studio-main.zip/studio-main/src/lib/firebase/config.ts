import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  projectId: "studio-1153264247-72a2a",
  appId: "1:38468599876:web:c8177a2dd8583e71fe7c11",
  apiKey: "AIzaSyCo_D9L8kjgDY-vTjm0i15-_dHRMiai_WQ",
  authDomain: "studio-1153264247-72a2a.firebaseapp.com",
  storageBucket: "studio-1153264247-72a2a.appspot.com",
  messagingSenderId: "38468599876",
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);
const auth = getAuth(app);

export { app, db, auth };
