// This file is not currently in use. The application is configured to use
// the mock database in /src/lib/db.ts. To switch to a live MongoDB instance,
// you would need to update the import paths in /src/ai/flows/partial-evidence-reasoning.ts
// and other files to point to this file instead of db.ts.

import { MongoClient, Db } from 'mongodb';

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  // This check is disabled when using the mock DB.
  // throw new Error('Please define the MONGODB_URI environment variable inside .env');
  console.warn("MONGODB_URI is not defined. Using mock database. To use a live database, please define MONGODB_URI in your .env file.");
}

/**
 * Global is used here to maintain a cached connection across hot reloads
 * in development. This prevents connections from growing exponentially
 * during API Route usage.
 */
// @ts-ignore
let cached: { conn: { client: MongoClient; db: Db } | null; promise: Promise<{ client: MongoClient; db: Db }> | null } = global.mongo;

if (!cached) {
  // @ts-ignore
  cached = global.mongo = { conn: null, promise: null };
}

export async function connectToDatabase() {
  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise && MONGODB_URI) {
    const opts = {};

    cached.promise = MongoClient.connect(MONGODB_URI!, opts).then((client) => {
      // You can change the database name here if you want.
      const db = client.db('college'); 
      return {
        client,
        db,
      };
    });
  }
  
  if (cached.promise) {
    cached.conn = await cached.promise;
    return cached.conn;
  }
  
  // This will happen if MONGODB_URI is not set
  return Promise.reject("MongoDB connection string is not provided.");
}
