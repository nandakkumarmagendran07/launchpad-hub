'use server';

import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  doc,
  limit,
  DocumentData,
  collectionGroup,
} from 'firebase/firestore';
import { db } from '@/lib/firebase/config';

// Helper to simulate network latency, can be removed if not needed.
const simulateDB = async <T>(data: T): Promise<T> => {
  await new Promise(resolve => setTimeout(resolve, 50));
  if (
    data === undefined ||
    (Array.isArray(data) && data.length === 0)
  ) {
    return data;
  }
  return data;
};

export const findStudentByName = async (name: string) => {
  const studentsRef = collection(db, 'students');
  const q = query(
    studentsRef,
    where('name', '==', name),
    limit(1)
  );
  const snapshot = await getDocs(q);

  if (snapshot.empty) {
    return simulateDB(null);
  }
  const studentDoc = snapshot.docs[0];
  return simulateDB({ _id: studentDoc.id, ...studentDoc.data() });
};

export const findFacultyByName = async (name:string) => {
    const facultyRef = collection(db, 'faculty');
    const q = query(facultyRef, where('name', '==', name), limit(1));
    const snapshot = await getDocs(q);

    if(snapshot.empty) {
        return simulateDB(null);
    }
    const facultyDoc = snapshot.docs[0];
    return simulateDB({ _id: facultyDoc.id, ...facultyDoc.data() });
}

export const getAttendanceByName = async (studentName: string, date: string): Promise<{ status: string | null }> => {
  console.log("ATTENDANCE TOOL CALLED WITH:", studentName, date);
  // Step 1: Find studentId from students collection
  const studentQuery = query(
    collection(db, "students"),
    where("name", "==", studentName),
    limit(1)
  );

  const studentSnap = await getDocs(studentQuery);

  if (studentSnap.empty) {
    console.log("ATTENDANCE QUERY RESULT: Student not found");
    return { status: null };
  }

  const studentId = studentSnap.docs[0].data().studentId;

  // Step 2: Query attendance collection using studentId and date
  const attendanceQuery = query(
    collection(db, "attendance"),
    where("studentId", "==", studentId),
    where("date", "==", date),
    limit(1)
  );
  
  const attendanceSnap = await getDocs(attendanceQuery);
  console.log("ATTENDANCE QUERY RESULT:", attendanceSnap.docs.length);

  if (attendanceSnap.empty) {
      return { status: null };
  }
  
  // Return the found data in a structured format.
  return {
    status: attendanceSnap.docs[0].data().status,
  };
};


export const getMarks = async (studentId: string, subject: string) => {
    const marksRef = collection(db, 'marks');
    const q = query(marksRef, where('studentId', '==', studentId), where('subject', '==', subject), limit(1));
    const snapshot = await getDocs(q);

    if(snapshot.empty){
        return simulateDB(null);
    }

    return simulateDB({ studentId, ...snapshot.docs[0].data()});
}

export const getLabLogsForStudent = async (studentId: string) => {
    const logsRef = collection(db, 'labLogs');
    const q = query(logsRef, where('studentId', '==', studentId));
    const snapshot = await getDocs(q);
    if(snapshot.empty) {
        return simulateDB(null);
    }
    return simulateDB(snapshot.docs.map(doc => doc.data()));
}

export const getStudentCount = async () => {
    const studentsRef = collection(db, 'students');
    const snapshot = await getDocs(studentsRef);
    return simulateDB(snapshot.size);
}

export const getAllStudents = async () => {
    const studentsRef = collection(db, 'students');
    const snapshot = await getDocs(studentsRef);
    if(snapshot.empty) {
        return simulateDB(null);
    }
    return simulateDB(snapshot.docs.map(doc => ({ _id: doc.id, ...doc.data() })));
}

export const getStudentRecords = async (studentId: string) => {
    const studentRef = doc(db, 'students', studentId);
    const studentSnap = await getDoc(studentRef);

    if (!studentSnap.exists()) {
        return simulateDB(null);
    }

    const attendanceRef = collection(db, 'attendance');
    const attendanceQuery = query(attendanceRef, where('studentId', '==', studentId));
    const attendanceSnap = await getDocs(attendanceQuery);

    const marksRef = collection(db, 'marks');
    const marksQuery = query(marksRef, where('studentId', '==', studentId));
    const marksSnap = await getDocs(marksQuery);

    const labLogsRef = collection(db, 'labLogs');
    const labLogsQuery = query(labLogsRef, where('studentId', '==', studentId));
    const labLogsSnap = await getDocs(labLogsQuery);
    
    return simulateDB({
        ...studentSnap.data(),
        attendance: attendanceSnap.docs.map(d => d.data()),
        marks: marksSnap.docs.map(d => d.data()),
        labLogs: labLogsSnap.docs.map(d => d.data()),
    });
}

export const getAllData = async () => {
    const students = await getAllStudents();
    const facultySnapshot = await getDocs(collection(db, 'faculty'));
    const faculty = facultySnapshot.docs.map(doc => ({_id: doc.id, ...doc.data()}));
    
    const attendanceSnapshot = await getDocs(collection(db, 'attendance'));
    const attendance = attendanceSnapshot.docs.map(doc => doc.data());

    const marksSnapshot = await getDocs(collection(db, 'marks'));
    const marks = marksSnapshot.docs.map(doc => doc.data());

    const timetable = await getFullTimetable();
    const classAssignments = await getAllClassAssignments();

    return simulateDB({
        students,
        faculty,
        attendance,
        marks,
        timetable,
        classAssignments
    })
}

const getFullTimetable = async () => {
    const timetableRef = collection(db, 'timetable');
    const snapshot = await getDocs(timetableRef);
    return snapshot.docs.map(doc => ({ day: doc.id, ...doc.data() }));
}

export const getTimetable = async (day: string) => {
    const formattedDay = day.charAt(0).toUpperCase() + day.slice(1).toLowerCase();
    const timetableRef = doc(db, 'timetable', formattedDay);
    const docSnap = await getDoc(timetableRef);

    if (!docSnap.exists()) {
        return simulateDB(null);
    }
    return simulateDB(docSnap.data().schedule);
}

const getAllClassAssignments = async () => {
    const assignmentsRef = collection(db, 'classAssignments');
    const snapshot = await getDocs(assignmentsRef);
    return snapshot.docs.map(doc => ({ classId: doc.id, ...doc.data() }));
}

export const getClassAssignment = async (classId: string) => {
    const assignmentRef = doc(db, 'classAssignments', classId);
    const docSnap = await getDoc(assignmentRef);
    
    if(!docSnap.exists()) {
        return simulateDB(null);
    }

    const assignment = docSnap.data();
    const facultyInfo = await getDoc(doc(db, 'faculty', assignment.facultyId));
    
    const studentInfoPromises = assignment.studentIds.map((id:string) => getDoc(doc(db, 'students', id)));
    const studentDocs = await Promise.all(studentInfoPromises);
    const students = studentDocs.map(s => s.data());

    return simulateDB({
        ...assignment,
        faculty: facultyInfo.data(),
        students: students,
    });
}
