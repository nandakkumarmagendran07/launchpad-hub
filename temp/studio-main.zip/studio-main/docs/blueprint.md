# **App Name**: Real-time data retrieval bot

## Core Features:

- Chat Interface: Provide a text-based interface for users to submit administrative queries and receive verifiable evidence-based answers.
- RESTful API Backend: Implement a Node.js backend with Express.js to handle API requests, manage database connections, and enforce evidence-based reasoning.
- MongoDB Integration: Connect to a MongoDB database containing administrative records (students, attendance, marks, lab logs, faculty).
- Evidence Verification: Verify each response against exact and partial matches in the database before providing an answer or refusing if no proof is found.
- Data Parsing: Use regex or NLP-safe parsing to extract relevant entities (student name, date, time, location, subject) from user queries for structured database querying.
- Partial Evidence Reasoning: The chatbot LLM uses a 'reasoning' tool when a perfect record match isn't available to see if related, supporting evidence exists for more accurate answer generation.

## Style Guidelines:

- Primary color: Navy blue (#2E4A62) for a professional and trustworthy feel.
- Background color: Light gray (#F0F4F7) to ensure readability and a clean interface.
- Accent color: Teal (#39A2A6) to highlight important information and call-to-action buttons.
- Body font: 'PT Sans', a humanist sans-serif for clear readability.
- Headline font: 'Space Grotesk', a sans-serif for a modern, administrative feel.
- Use simple, professional icons for representing administrative functions.
- Design a clean, intuitive layout that prioritizes clarity and easy access to administrative data.
- Implement subtle animations for feedback and loading states.